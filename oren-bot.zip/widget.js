/* Oren bot website widget.
   Add to any site, just before </body>:
   <script src="https://YOUR-BOT.vercel.app/widget.js" defer></script>
   Optional: data-side="right" to put the button on the right. */
(function () {
  if (window.__orenBotLoaded) return;
  window.__orenBotLoaded = true;
  var me = document.currentScript || document.querySelector('script[src*="widget.js"]');
  var API = new URL(me.src).origin;
  var side = (me.getAttribute("data-side") || "left") === "right" ? "right" : "left";

  var session;
  try { session = localStorage.getItem("orenbot_session"); } catch (e) {}
  if (!session) {
    session = "s" + Math.random().toString(36).slice(2) + Date.now().toString(36);
    try { localStorage.setItem("orenbot_session", session); } catch (e) {}
  }

  var host = document.createElement("div");
  host.style.cssText = "position:fixed;z-index:2147483000;bottom:0;" + side + ":0";
  document.body.appendChild(host);
  var root = host.attachShadow({ mode: "open" });

  root.innerHTML =
    '<style>' +
    ':host{all:initial}' +
    '*{box-sizing:border-box;font-family:system-ui,-apple-system,"Segoe UI",Arial,sans-serif}' +
    '.btn{position:fixed;bottom:20px;' + side + ':20px;width:58px;height:58px;border-radius:50%;border:none;cursor:pointer;background:var(--c);color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.25);display:grid;place-items:center;transition:transform .15s}' +
    '.btn:hover{transform:scale(1.06)}.btn svg{width:26px;height:26px}' +
    '.panel{position:fixed;bottom:90px;' + side + ':20px;width:min(370px,calc(100vw - 32px));height:min(540px,calc(100vh - 120px));background:#fff;color:#14141c;border-radius:18px;box-shadow:0 12px 48px rgba(0,0,0,.28);display:flex;flex-direction:column;overflow:hidden;direction:rtl}' +
    '.panel[hidden]{display:none}' +
    '.top{background:var(--c);color:#fff;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;font-weight:700;font-size:16px}' +
    '.x{background:none;border:none;color:#fff;font-size:22px;cursor:pointer;line-height:1}' +
    '.log{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:8px;background:#f5f5f8}' +
    '.m{max-width:82%;padding:9px 12px;border-radius:14px;font-size:15px;line-height:1.45;white-space:pre-wrap;word-wrap:break-word}' +
    '.u{align-self:flex-start;background:var(--c);color:#fff;border-bottom-right-radius:4px}' +
    '.b{align-self:flex-end;background:#fff;border:1px solid #e4e4ec;border-bottom-left-radius:4px}' +
    '.t{color:#888}' +
    'form{display:flex;gap:8px;padding:10px;border-top:1px solid #e4e4ec;background:#fff}' +
    'input{flex:1;min-width:0;border:1px solid #d8d8e2;border-radius:12px;padding:10px 12px;font-size:15px;outline:none;color:#14141c;background:#fff}' +
    'input:focus{border-color:var(--c)}' +
    '.s{border:none;background:var(--c);color:#fff;border-radius:12px;padding:0 16px;font-weight:700;cursor:pointer;font-size:15px}' +
    '.s:disabled{opacity:.5}' +
    '</style>' +
    '<button class="btn" aria-label="צ\'אט"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></button>' +
    '<div class="panel" hidden><div class="top"><span class="name">צ\'אט</span><button class="x" aria-label="סגור">×</button></div>' +
    '<div class="log"></div><form><input placeholder="כתוב הודעה…" aria-label="הודעה" maxlength="2000"><button class="s" type="submit">שלח</button></form></div>';

  var $ = function (s) { return root.querySelector(s); };
  var panel = $(".panel"), log = $(".log"), input = $("input"), sendBtn = $(".s");
  var cfg = { botName: "צ'אט", welcome: "היי! איך אפשר לעזור?", color: "#7c6cff" };
  var count = 0, busy = false, timer = null;

  function setColor(c) { host.style.setProperty("--c", c); }
  setColor(cfg.color);

  fetch(API + "/api/chat?config=1").then(function (r) { return r.json(); }).then(function (c) {
    cfg = c; $(".name").textContent = c.botName; setColor(c.color || "#7c6cff");
  }).catch(function () {});

  function add(role, text, cls) {
    var d = document.createElement("div");
    d.className = "m " + (role === "user" ? "u" : "b") + (cls ? " " + cls : "");
    d.dir = "auto"; d.textContent = text;
    log.appendChild(d); log.scrollTop = log.scrollHeight; return d;
  }
  function load() {
    return fetch(API + "/api/chat?session=" + session).then(function (r) { return r.json(); }).then(function (j) {
      var msgs = j.messages || [];
      if (msgs.length === count && count) return;
      count = msgs.length; log.innerHTML = "";
      add("bot", cfg.welcome);
      msgs.forEach(function (m) { add(m.role, m.text); });
    }).catch(function () { if (!count) { log.innerHTML = ""; add("bot", cfg.welcome); } });
  }
  function open() {
    panel.hidden = false; load(); input.focus();
    clearInterval(timer); timer = setInterval(function () { if (!busy) load(); }, 8000);
  }
  function close() { panel.hidden = true; clearInterval(timer); }

  $(".btn").onclick = function () { panel.hidden ? open() : close(); };
  $(".x").onclick = close;
  $("form").onsubmit = function (e) {
    e.preventDefault();
    var text = input.value.trim(); if (!text || busy) return;
    busy = true; sendBtn.disabled = true; input.value = "";
    add("user", text); var t = add("bot", "מקליד…", "t");
    fetch(API + "/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ session: session, text: text }) })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        t.remove();
        if (j.reply) add("bot", j.reply);
        else if (j.error) add("bot", "משהו לא עבד, נסה שוב עוד רגע.");
        count += j.reply ? 2 : 1;
      })
      .catch(function () { t.remove(); add("bot", "אין חיבור כרגע, נסה שוב."); })
      .then(function () { busy = false; sendBtn.disabled = false; input.focus(); });
  };
})();
