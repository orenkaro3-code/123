// Mobile menu + stat count-up.
(function () {
  var body = document.body;
  var burger = document.querySelector(".burger");
  var menu = document.getElementById("mobileMenu");
  var overlay = document.querySelector(".menu-overlay");

  function setMenu(open) {
    burger.setAttribute("aria-expanded", String(open));
    menu.hidden = !open;
    overlay.hidden = !open;
    body.classList.toggle("menu-open", open);
  }
  burger.addEventListener("click", function () { setMenu(menu.hidden); });
  overlay.addEventListener("click", function () { setMenu(false); });
  menu.querySelectorAll("a").forEach(function (a) { a.addEventListener("click", function () { setMenu(false); }); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") setMenu(false); });
  window.addEventListener("resize", function () { if (window.innerWidth > 720 && !menu.hidden) setMenu(false); });

  // Count-up
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var easeOutCubic = function (t) { return 1 - Math.pow(1 - t, 3); };
  function show(el, v) {
    var dec = +el.dataset.decimals || 0;
    el.textContent = (el.dataset.prefix || "") + v.toFixed(dec) + (el.dataset.suffix || "");
  }
  function run(el, i) {
    var target = parseFloat(el.dataset.target);
    if (reduce) return show(el, target);
    var duration = 1500 + i * 80;
    setTimeout(function () {
      var start = performance.now();
      (function tick(now) {
        var t = Math.min(1, (now - start) / duration);
        show(el, target * easeOutCubic(t));
        if (t < 1) requestAnimationFrame(tick);
      })(start);
    }, 480 + i * 90);
  }
  var values = document.querySelectorAll(".stat-value");
  var done = false;
  var io = new IntersectionObserver(function (entries) {
    if (done || !entries.some(function (e) { return e.isIntersecting; })) return;
    done = true;
    values.forEach(run);
    io.disconnect();
  }, { threshold: 0.25 });
  values.forEach(function (v) { io.observe(v); });
})();
