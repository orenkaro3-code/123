# הבוט של אורן

בוט שעונה ללקוחות **באתר, בוואטסאפ (Meta) ובמייל**, לומד את המידע מאתר שמדביקים לו, ושומר את כל השיחות בפאנל ניהול. אפשר גם לחבר אותו ל-Claude ולשאול "מי שלח הודעה היום?".

## מה יש בפרויקט

| קובץ | מה הוא עושה |
|---|---|
| `index.html`, `styles.css`, `main.js` | דף הבית (עיצוב עם וידאו ברקע) |
| `admin.html` | פאנל ניהול: שיחות, סריקת אתר, הגדרות, חיבורים |
| `demo.html` | עמוד ניסיון עם הבוט |
| `widget.js` | הבועה שמדביקים בכל אתר |
| `api/chat.js` | צ'אט מהאתר |
| `api/whatsapp.js` | חיבור לוואטסאפ (Meta Cloud API) |
| `api/email.js` | חיבור למייל (דרך Gmail + Apps Script) |
| `api/admin.js` | ה-API של פאנל הניהול |
| `api/mcp.js` | חיבור ל-Claude (custom connector) |
| `api/_lib.js` | המוח: Gemini, מסד נתונים, סריקת אתרים |

## התקנה

### 1. להעלות ל-GitHub ול-Vercel
1. פותחים repository חדש ב-GitHub ומעלים את כל הקבצים (Add file ← Upload files).
2. ב-Vercel: Add New ← Project ← בוחרים את ה-repository ← Deploy. (או מחברים אותו לפרויקט `oren-bot` שכבר קיים: Settings ← Git.)

### 2. משתני סביבה (Vercel ← Settings ← Environment Variables)

| שם | מה זה | חובה |
|---|---|---|
| `ADMIN_PASSWORD` | הסיסמה לפאנל הניהול | כן |
| `BOT_SECRET` | מפתח סודי ארוך (לחיבור Claude ולמייל) | כן |
| `GEMINI_API_KEY` | מפתח חינמי מ-[Google AI Studio](https://aistudio.google.com/apikey) | כן |
| `KV_REST_API_URL` + `KV_REST_API_TOKEN` | מסד נתונים Upstash. נוצרים לבד בשלב 3 | כן |
| `WA_TOKEN` | טוקן מ-Meta | לוואטסאפ |
| `WA_PHONE_ID` | Phone number ID מ-Meta | לוואטסאפ |
| `WA_VERIFY_TOKEN` | מילה סודית שאתה ממציא | לוואטסאפ |
| `GEMINI_MODEL` | לא חובה. ברירת מחדל: `gemini-flash-latest` | לא |

אחרי כל שינוי במשתנים: Deployments ← שלוש נקודות ← **Redeploy**.

### 3. מסד נתונים (חינם)
Vercel ← Storage ← בוחרים את מסד ה-Upstash (Redis) הקיים, או יוצרים חדש ← **Connect Project** ← `oren-bot`. המשתנים `KV_REST_API_URL` ו-`KV_REST_API_TOKEN` נוספים לבד. ואז Redeploy.

### 4. ללמד את הבוט אתר
נכנסים ל-`https://<האתר-שלך>.vercel.app/admin.html` עם הסיסמה ← "ידע מהאתר" ← מדביקים קישור ← סרוק. בלשונית הזאת אפשר גם לשאול את הבוט שאלת בדיקה.

### 5. בועה באתר
בלשונית "חיבורים" יש שורת קוד. מדביקים אותה לפני `</body>` בכל אתר:
```html
<script src="https://<האתר-שלך>.vercel.app/widget.js" defer></script>
```

### 6. וואטסאפ דרך Meta
1. נכנסים ל-[developers.facebook.com](https://developers.facebook.com) ← My Apps ← Create App ← בוחרים **Business**.
2. מוסיפים את המוצר **WhatsApp** ← API Setup.
3. מעתיקים משם את ה-**Temporary access token** ל-`WA_TOKEN`, ואת ה-**Phone number ID** ל-`WA_PHONE_ID`. ממציאים מילה ל-`WA_VERIFY_TOKEN`. אחר כך עושים Redeploy.
4. WhatsApp ← Configuration ← Webhook ← Edit:
   - Callback URL: `https://<האתר-שלך>.vercel.app/api/whatsapp`
   - Verify token: אותה מילה מ-`WA_VERIFY_TOKEN`
   - Verify and save, ואז ליד **messages** לוחצים Subscribe.
5. ב-API Setup מוסיפים את מספר הטלפון שלך לרשימת הנמענים, ושולחים הודעה למספר הבדיקה.

כמה דברים חשובים:
- הטוקן הזמני פג אחרי בערך יום. לטוקן קבוע צריך ליצור System User ב-Business Settings ולתת לו הרשאה `whatsapp_business_messaging`.
- מספר הבדיקה מוגבל לרשימה קצרה של מספרים מאומתים. כדי לענות לכל אחד צריך להוסיף מספר אמיתי, ו-Meta יכולה לבקש אימות עסק.
- תשובות בתוך 24 שעות מההודעה של הלקוח חינמיות עד 1,000 בחודש לכל מספר.

### 7. מייל (Gmail)
1. נכנסים ל-[script.google.com](https://script.google.com) ← New project.
2. מדביקים את הקוד מלשונית "חיבורים" בפאנל. המפתח כבר בפנים.
3. בוחרים את הפונקציה `setup` ← Run ← מאשרים הרשאות.
4. מעכשיו, כל 5 דקות הבוט עונה למיילים חדשים בתיבה הראשית.

עדיף להשתמש בכתובת Gmail נפרדת לעסק, כדי שהבוט לא יענה למיילים האישיים שלך.

### 8. חיבור ל-Claude
Claude ← Settings ← Connectors ← **Add custom connector** ← מדביקים את הכתובת מלשונית "חיבורים":
```
https://<האתר-שלך>.vercel.app/api/mcp?key=<BOT_SECRET>
```
ואז אפשר לשאול את Claude דברים כמו "מי שלח הודעה היום?", "תראה לי את השיחה עם דני", או "תענה לו שאנחנו פתוחים עד 22". Claude שולח תשובה רק אחרי שאתה מאשר את הנוסח.

## איך זה עובד
1. לקוח כותב באתר, בוואטסאפ או במייל.
2. השרת שומר את ההודעה, ו-Gemini עונה רק לפי המידע מהאתר שסרקת.
3. אם אין לבוט תשובה, הוא אומר שהוא מעביר את השאלה אליך.
4. בפאנל אתה רואה את כל השיחות, יכול לסמן "אני עונה" כדי להשהות את הבוט, ולכתוב תשובה בעצמך. התשובה נשלחת באותו ערוץ שבו הלקוח כתב.

**שמור את הסיסמה ואת `BOT_SECRET` בסוד, ואל תעלה אותם ל-GitHub.** הם נמצאים רק במשתני הסביבה ב-Vercel.
