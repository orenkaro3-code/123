// Admin API for the panel. Every call needs the x-admin-password header.
// GET  ?action=status|list|conv&id=|settings|kb
// POST ?action=reply {id,text} | pause {id,paused} | read {id} | delete {id} | settings {...} | scan {url} | test {text}
import {
  cors, readBody, isAdmin, status, listConvs, getConv, saveConv, deleteConv, deliverAdminReply,
  getSettings, saveSettings, getKB, scanSite, aiReply, friendlyError,
} from "./_lib.js";

export default async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();
  if (!process.env.ADMIN_PASSWORD) return res.status(500).json({ error: "ADMIN_PASSWORD לא מוגדר בפרויקט" });
  if (!isAdmin(req)) return res.status(401).json({ error: "סיסמה שגויה" });
  const a = req.query.action;
  try {
    if (req.method === "GET") {
      if (a === "status") return res.json({
        ...status(),
        botSecret: (process.env.BOT_SECRET || "").trim(),
        verifyToken: (process.env.WA_VERIFY_TOKEN || "").trim(),
      });
      if (a === "list") return res.json({ convs: await listConvs(100) });
      if (a === "conv") return res.json({ conv: await getConv(String(req.query.id)) });
      if (a === "settings") return res.json(await getSettings());
      if (a === "kb") {
        const kb = await getKB();
        return res.json({ url: kb.url, pages: kb.pages, scannedAt: kb.scannedAt, chars: kb.text.length, preview: kb.text.slice(0, 1500) });
      }
      return res.status(400).json({ error: "פעולה לא מוכרת" });
    }
    if (req.method !== "POST") return res.status(405).end();
    const b = await readBody(req);
    if (a === "reply") {
      const t = String(b.text || "").trim();
      if (!t) return res.status(400).json({ error: "הודעה ריקה" });
      return res.json({ conv: await deliverAdminReply(String(b.id), t) });
    }
    if (a === "pause" || a === "read") {
      const c = await getConv(String(b.id));
      if (!c) return res.status(404).json({ error: "השיחה לא נמצאה" });
      if (a === "pause") c.botPaused = Boolean(b.paused);
      c.unread = 0;
      return res.json({ conv: await saveConv(c) });
    }
    if (a === "delete") { await deleteConv(String(b.id)); return res.json({ ok: true }); }
    if (a === "settings") return res.json(await saveSettings(b));
    if (a === "scan") {
      const kb = await scanSite(String(b.url || ""));
      return res.json({ url: kb.url, pages: kb.pages, scannedAt: kb.scannedAt, chars: kb.text.length });
    }
    if (a === "test") {
      const reply = await aiReply({ messages: [{ role: "user", text: String(b.text || "היי") }] });
      return res.json({ reply });
    }
    return res.status(400).json({ error: "פעולה לא מוכרת" });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: friendlyError(e) });
  }
}
