// Shared helpers: storage (Upstash Redis REST), AI (Gemini), channels, site scanning.

const env = (k) => (process.env[k] || "").trim();

// ---------- Storage ----------
const REDIS_URL = env("KV_REST_API_URL") || env("UPSTASH_REDIS_REST_URL");
const REDIS_TOKEN = env("KV_REST_API_TOKEN") || env("UPSTASH_REDIS_REST_TOKEN");
const P = "obot:"; // key prefix, so a shared database stays tidy

export function storageReady() {
  return Boolean(REDIS_URL && REDIS_TOKEN);
}

async function redis(cmd) {
  if (!storageReady()) throw new Error("STORAGE_NOT_CONNECTED");
  const r = await fetch(REDIS_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${REDIS_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify(cmd),
  });
  const j = await r.json();
  if (j.error) throw new Error("Redis: " + j.error);
  return j.result;
}

async function pipeline(cmds) {
  if (!cmds.length) return [];
  if (!storageReady()) throw new Error("STORAGE_NOT_CONNECTED");
  const r = await fetch(REDIS_URL.replace(/\/$/, "") + "/pipeline", {
    method: "POST",
    headers: { Authorization: `Bearer ${REDIS_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify(cmds),
  });
  const j = await r.json();
  return j.map((x) => x.result);
}

async function getJSON(key, fallback) {
  const v = await redis(["GET", P + key]);
  if (!v) return fallback;
  try { return JSON.parse(v); } catch { return fallback; }
}
async function setJSON(key, val) {
  await redis(["SET", P + key, JSON.stringify(val)]);
}

// ---------- Settings & knowledge ----------
export const DEFAULT_SETTINGS = {
  botName: "הבוט של אורן",
  welcome: "היי! איך אפשר לעזור?",
  persona: "תענה בעברית, קצר, חם וברור.",
  color: "#7c6cff",
  handoffText: "אני מעביר את זה לאורן, הוא יחזור אליך בהקדם.",
};

export async function getSettings() {
  return { ...DEFAULT_SETTINGS, ...(await getJSON("settings", {})) };
}
export async function saveSettings(s) {
  const clean = {};
  for (const k of Object.keys(DEFAULT_SETTINGS)) if (typeof s[k] === "string") clean[k] = s[k].slice(0, 4000);
  await setJSON("settings", { ...(await getJSON("settings", {})), ...clean });
  return getSettings();
}
export async function getKB() {
  return getJSON("kb", { url: "", pages: [], text: "", scannedAt: null });
}
export async function saveKB(kb) {
  await setJSON("kb", kb);
}

// ---------- Conversations ----------
// id format: web:<session> | wa:<phone> | email:<address>
export async function getConv(id) {
  return getJSON("conv:" + id, null);
}

export async function saveConv(c) {
  c.updatedAt = Date.now();
  if (c.messages.length > 200) c.messages = c.messages.slice(-200);
  await pipeline([
    ["SET", P + "conv:" + c.id, JSON.stringify(c)],
    ["ZADD", P + "convs", String(c.updatedAt), c.id],
  ]);
  return c;
}

export async function addMessage(id, { channel, contact, name }, role, text) {
  let c = await getConv(id);
  if (!c) c = { id, channel, contact, name: name || "", createdAt: Date.now(), botPaused: false, unread: 0, messages: [] };
  if (name && !c.name) c.name = name;
  c.messages.push({ role, text: String(text).slice(0, 8000), at: Date.now() });
  if (role === "user") c.unread = (c.unread || 0) + 1;
  return saveConv(c);
}

export async function listConvs(limit = 50) {
  const ids = await redis(["ZREVRANGE", P + "convs", "0", String(Math.max(0, limit - 1))]);
  if (!ids || !ids.length) return [];
  const vals = await redis(["MGET", ...ids.map((i) => P + "conv:" + i)]);
  return vals.filter(Boolean).map((v) => {
    const c = JSON.parse(v);
    const last = c.messages[c.messages.length - 1];
    return {
      id: c.id, channel: c.channel, contact: c.contact, name: c.name, botPaused: c.botPaused,
      unread: c.unread || 0, updatedAt: c.updatedAt, count: c.messages.length,
      last: last ? { role: last.role, text: last.text.slice(0, 160), at: last.at } : null,
    };
  });
}

export async function deleteConv(id) {
  await pipeline([["DEL", P + "conv:" + id], ["ZREM", P + "convs", id]]);
}

// True only the first time an external message id is seen (Meta can deliver twice).
export async function firstTime(id) {
  const r = await redis(["SET", P + "seen:" + id, "1", "NX", "EX", "86400"]);
  return r === "OK";
}

export async function pushEmailOutbox(item) {
  await redis(["RPUSH", P + "email:out", JSON.stringify(item)]);
}
export async function popEmailOutbox() {
  const items = await pipeline([
    ["LRANGE", P + "email:out", "0", "-1"],
    ["DEL", P + "email:out"],
  ]);
  return (items[0] || []).map((x) => JSON.parse(x));
}

// ---------- AI ----------
export function aiReady() {
  return Boolean(env("GEMINI_API_KEY"));
}

export async function aiReply(conv) {
  if (!aiReady()) throw new Error("GEMINI_KEY_MISSING");
  const s = await getSettings();
  const kb = await getKB();
  const system =
    `אתה ${s.botName}, בוט שעונה ללקוחות בשם העסק.\n` +
    `הנחיות סגנון: ${s.persona}\n` +
    `ענה תמיד בשפה שבה הלקוח כתב. תשובות קצרות, בלי markdown כבד (זה גם וואטסאפ ומייל).\n` +
    (kb.text
      ? `ענה רק לפי המידע מהאתר שמופיע למטה. אם התשובה לא שם, אל תמציא. תגיד בדיוק: "${s.handoffText}"\n\n=== מידע מהאתר (${kb.url}) ===\n${kb.text.slice(0, 60000)}`
      : `עדיין אין מידע מהאתר. אם לא בטוח בתשובה, אל תמציא ותגיד: "${s.handoffText}"`);

  const contents = [];
  for (const m of conv.messages.slice(-20)) {
    const role = m.role === "user" ? "user" : "model";
    const last = contents[contents.length - 1];
    if (last && last.role === role) last.parts[0].text += "\n" + m.text;
    else contents.push({ role, parts: [{ text: m.text }] });
  }
  while (contents.length && contents[0].role !== "user") contents.shift();
  if (!contents.length) return null;

  const model = env("GEMINI_MODEL") || "gemini-flash-latest";
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": env("GEMINI_API_KEY") },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents,
      generationConfig: { temperature: 0.4, maxOutputTokens: 800 },
    }),
  });
  const j = await r.json();
  if (!r.ok) throw new Error("Gemini: " + (j.error?.message || r.status));
  const text = (j.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("").trim();
  return text || null;
}

// Full flow for an incoming customer message: store it, answer unless a human took over.
export async function handleIncoming(id, meta, text) {
  let c = await addMessage(id, meta, "user", text);
  if (c.botPaused) return { conv: c, reply: null };
  let reply;
  try {
    reply = await aiReply(c);
  } catch (e) {
    console.error(e);
    reply = (await getSettings()).handoffText;
  }
  if (reply) c = await addMessage(id, meta, "bot", reply);
  return { conv: c, reply };
}

// ---------- WhatsApp (Meta Cloud API) ----------
export function waReady() {
  return Boolean(env("WA_TOKEN") && env("WA_PHONE_ID"));
}
export async function sendWhatsApp(to, text) {
  const v = env("WA_GRAPH_VERSION") || "v23.0";
  const r = await fetch(`https://graph.facebook.com/${v}/${env("WA_PHONE_ID")}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${env("WA_TOKEN")}`, "Content-Type": "application/json" },
    body: JSON.stringify({ messaging_product: "whatsapp", to, type: "text", text: { body: text.slice(0, 4000) } }),
  });
  if (!r.ok) throw new Error("WhatsApp: " + (await r.text()).slice(0, 300));
}

// Deliver a reply written by Oren (from the panel or from Claude) on the right channel.
export async function deliverAdminReply(id, text) {
  const c = await getConv(id);
  if (!c) throw new Error("השיחה לא נמצאה");
  if (c.channel === "wa") await sendWhatsApp(c.contact, text);
  if (c.channel === "email") {
    const subj = c.subject ? (/^re:/i.test(c.subject) ? c.subject : "Re: " + c.subject) : "תשובה";
    await pushEmailOutbox({ to: c.contact, subject: subj, text });
  }
  c.messages.push({ role: "admin", text, at: Date.now() });
  c.unread = 0;
  return saveConv(c);
}

// ---------- Site scanning ----------
function htmlToText(html) {
  return html
    .replace(/<(script|style|noscript|svg|iframe)[\s\S]*?<\/\1>/gi, " ")
    .replace(/<(br|\/p|\/div|\/li|\/h\d|\/tr)[^>]*>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n))
    .replace(/[ \t\r\f\v]+/g, " ")
    .replace(/\n\s*\n+/g, "\n")
    .trim();
}

export async function scanSite(startUrl, maxPages = 20) {
  let start;
  try { start = new URL(startUrl.startsWith("http") ? startUrl : "https://" + startUrl); }
  catch { throw new Error("קישור לא תקין"); }
  const queue = [start.href.split("#")[0]];
  const seen = new Set(queue);
  const pages = [];
  let text = "";
  while (queue.length && pages.length < maxPages && text.length < 80000) {
    const url = queue.shift();
    let html;
    try {
      const ctl = AbortSignal.timeout(8000);
      const r = await fetch(url, { signal: ctl, headers: { "User-Agent": "Mozilla/5.0 (OrenBot site reader)" } });
      if (!r.ok || !(r.headers.get("content-type") || "").includes("text/html")) continue;
      html = await r.text();
    } catch { continue; }
    const title = (html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || url).trim().slice(0, 120);
    const desc = html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)/i)?.[1] || "";
    const body = htmlToText(html);
    pages.push({ url, title, chars: body.length });
    text += `\n\n--- עמוד: ${title} (${url}) ---\n${desc ? desc + "\n" : ""}${body.slice(0, 12000)}`;
    for (const m of html.matchAll(/href=["']([^"'#]+)["']/gi)) {
      try {
        const u = new URL(m[1], url);
        if (u.host !== start.host || !/^https?:$/.test(u.protocol)) continue;
        if (/\.(png|jpe?g|gif|webp|svg|pdf|zip|mp4|css|js|ico|xml)$/i.test(u.pathname)) continue;
        const clean = u.origin + u.pathname + u.search;
        if (!seen.has(clean)) { seen.add(clean); queue.push(clean); }
      } catch {}
    }
  }
  if (!pages.length) throw new Error("לא הצלחתי לקרוא את האתר. בדוק שהקישור נכון ושהאתר פתוח לכולם.");
  const kb = { url: start.href, pages, text: text.trim(), scannedAt: Date.now() };
  await saveKB(kb);
  return kb;
}

// ---------- HTTP helpers ----------
export function cors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type,x-admin-password");
}

export async function readBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") { try { return JSON.parse(req.body); } catch { return {}; } }
  const chunks = [];
  for await (const ch of req) chunks.push(ch);
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"); } catch { return {}; }
}

export function isAdmin(req) {
  const pw = env("ADMIN_PASSWORD");
  return Boolean(pw) && req.headers["x-admin-password"] === pw;
}
export function hasBotSecret(val) {
  const s = env("BOT_SECRET");
  return Boolean(s) && val === s;
}

export function status() {
  return {
    storage: storageReady(),
    ai: aiReady(),
    whatsapp: waReady(),
    whatsappVerify: Boolean(env("WA_VERIFY_TOKEN")),
    botSecret: Boolean(env("BOT_SECRET")),
  };
}

export function friendlyError(e) {
  const m = String(e?.message || e);
  if (m === "STORAGE_NOT_CONNECTED") return "מסד הנתונים עוד לא מחובר לפרויקט (שלב 1 במדריך).";
  if (m === "GEMINI_KEY_MISSING") return "חסר מפתח Gemini (שלב 2 במדריך).";
  return m;
}
