// A small MCP server (Streamable HTTP, JSON responses) so Claude can read and answer the bot's conversations.
// Add it in Claude as a custom connector: https://<site>/api/mcp?key=BOT_SECRET
import { readBody, hasBotSecret, listConvs, getConv, deliverAdminReply, saveConv, getKB, status, friendlyError } from "./_lib.js";

const CH = { web: "אתר", wa: "וואטסאפ", email: "אימייל" };
const fmtTime = (t) => new Date(t).toLocaleString("he-IL", { timeZone: "Asia/Jerusalem" });

const TOOLS = [
  {
    name: "list_conversations",
    description: "List the most recent bot conversations (website, WhatsApp, email): who wrote, on which channel, when, the last message, and unread count. Use this to answer 'who messaged today?'.",
    inputSchema: {
      type: "object",
      properties: {
        limit: { type: "number", description: "How many conversations, newest first (default 20, max 100)" },
        channel: { type: "string", enum: ["web", "wa", "email"], description: "Only this channel" },
        since_hours: { type: "number", description: "Only conversations active in the last N hours" },
        unread_only: { type: "boolean" },
      },
    },
    annotations: { readOnlyHint: true },
  },
  {
    name: "get_conversation",
    description: "Read the full message history of one conversation by its id (from list_conversations).",
    inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] },
    annotations: { readOnlyHint: true },
  },
  {
    name: "search_messages",
    description: "Search the text of recent conversations (latest 100) for a word or phrase. Returns matching messages with their conversation id.",
    inputSchema: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
    annotations: { readOnlyHint: true },
  },
  {
    name: "send_reply",
    description: "Send a reply as Oren (a human) in a conversation. It is delivered on the same channel: WhatsApp message, email, or shown in the website chat. Only use after the user approved the exact text.",
    inputSchema: {
      type: "object",
      properties: { id: { type: "string" }, text: { type: "string" }, pause_bot: { type: "boolean", description: "Also stop the bot from answering in this conversation" } },
      required: ["id", "text"],
    },
    annotations: { destructiveHint: false, openWorldHint: true },
  },
  {
    name: "bot_status",
    description: "Which parts of the bot are connected (storage, AI, WhatsApp) and which website it learned from.",
    inputSchema: { type: "object", properties: {} },
    annotations: { readOnlyHint: true },
  },
];

async function callTool(name, args = {}) {
  if (name === "list_conversations") {
    let list = await listConvs(Math.min(Number(args.limit) || 20, 100));
    if (args.channel) list = list.filter((c) => c.channel === args.channel);
    if (args.since_hours) list = list.filter((c) => c.updatedAt > Date.now() - Number(args.since_hours) * 3600e3);
    if (args.unread_only) list = list.filter((c) => c.unread > 0);
    if (!list.length) return "אין שיחות שמתאימות.";
    return list.map((c) =>
      `• ${c.name || c.contact} | ${CH[c.channel] || c.channel} | ${fmtTime(c.updatedAt)} | ${c.unread ? c.unread + " לא נקראו | " : ""}${c.botPaused ? "בוט מושהה | " : ""}id: ${c.id}\n  אחרון (${c.last?.role}): ${c.last?.text || ""}`
    ).join("\n");
  }
  if (name === "get_conversation") {
    const c = await getConv(String(args.id));
    if (!c) return "השיחה לא נמצאה.";
    const who = { user: c.name || "לקוח", bot: "בוט", admin: "אורן" };
    return `שיחה עם ${c.name || c.contact} (${CH[c.channel]}, ${c.contact})${c.subject ? "\nנושא: " + c.subject : ""}\n\n` +
      c.messages.map((m) => `[${fmtTime(m.at)}] ${who[m.role] || m.role}: ${m.text}`).join("\n");
  }
  if (name === "search_messages") {
    const q = String(args.query || "").toLowerCase();
    if (!q) return "חסר טקסט לחיפוש.";
    const list = await listConvs(100);
    const out = [];
    for (const s of list) {
      const c = await getConv(s.id);
      for (const m of c?.messages || []) if (m.text.toLowerCase().includes(q)) out.push(`[${fmtTime(m.at)}] ${c.name || c.contact} (${CH[c.channel]}, id: ${c.id}) ${m.role}: ${m.text.slice(0, 300)}`);
      if (out.length >= 40) break;
    }
    return out.length ? out.join("\n") : "לא נמצא.";
  }
  if (name === "send_reply") {
    const c = await deliverAdminReply(String(args.id), String(args.text || ""));
    if (args.pause_bot) { c.botPaused = true; await saveConv(c); }
    return `נשלח ל-${c.name || c.contact} ב${CH[c.channel]}.`;
  }
  if (name === "bot_status") {
    const s = status();
    const kb = await getKB().catch(() => ({}));
    return JSON.stringify({ ...s, learnedFrom: kb.url || null, pages: kb.pages?.length || 0 });
  }
  throw new Error("Unknown tool " + name);
}

export default async function handler(req, res) {
  if (!hasBotSecret(req.query.key)) return res.status(401).json({ error: "bad key" });
  if (req.method === "GET") return res.status(405).setHeader("Allow", "POST").end();
  if (req.method === "DELETE") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).end();

  const body = await readBody(req);
  const batch = Array.isArray(body) ? body : [body];
  const out = [];
  for (const msg of batch) {
    if (msg.id === undefined || msg.id === null) continue; // notification
    const reply = (result) => out.push({ jsonrpc: "2.0", id: msg.id, result });
    try {
      if (msg.method === "initialize") {
        reply({
          protocolVersion: msg.params?.protocolVersion || "2025-06-18",
          capabilities: { tools: { listChanged: false } },
          serverInfo: { name: "oren-bot", version: "1.0.0" },
          instructions: "Read and answer the conversations of Oren's customer bot (website, WhatsApp, email). Never send a reply without the user's approval of the exact text.",
        });
      } else if (msg.method === "ping") reply({});
      else if (msg.method === "tools/list") reply({ tools: TOOLS });
      else if (msg.method === "tools/call") {
        try {
          const text = await callTool(msg.params?.name, msg.params?.arguments || {});
          reply({ content: [{ type: "text", text }] });
        } catch (e) {
          reply({ content: [{ type: "text", text: "שגיאה: " + friendlyError(e) }], isError: true });
        }
      } else out.push({ jsonrpc: "2.0", id: msg.id, error: { code: -32601, message: "Method not found" } });
    } catch (e) {
      out.push({ jsonrpc: "2.0", id: msg.id, error: { code: -32603, message: String(e.message || e) } });
    }
  }
  if (!out.length) return res.status(202).end();
  res.setHeader("Content-Type", "application/json");
  return res.status(200).send(JSON.stringify(Array.isArray(body) ? out : out[0]));
}
