// Email channel, driven by a small Google Apps Script in Oren's Gmail (see the guide).
// POST /api/email?key=BOT_SECRET {from, name, subject, text, messageId} -> {reply}
// GET  /api/email?key=BOT_SECRET -> replies Oren wrote in the panel, for the script to send
import { readBody, handleIncoming, hasBotSecret, popEmailOutbox, saveConv, firstTime, friendlyError } from "./_lib.js";

export default async function handler(req, res) {
  if (!hasBotSecret(req.query.key)) return res.status(401).json({ error: "מפתח שגוי" });
  try {
    if (req.method === "GET") return res.json({ outbox: await popEmailOutbox() });
    if (req.method !== "POST") return res.status(405).end();
    const b = await readBody(req);
    const from = String(b.from || "").toLowerCase().match(/[^\s<>"]+@[^\s<>"]+/)?.[0];
    if (!from) return res.status(400).json({ error: "חסר שולח" });
    if (b.messageId && !(await firstTime("mail:" + b.messageId))) return res.json({ reply: null, duplicate: true });
    const subject = String(b.subject || "").slice(0, 200);
    const text = `${subject ? "נושא: " + subject + "\n" : ""}${String(b.text || "").slice(0, 6000)}`;
    const { conv, reply } = await handleIncoming("email:" + from, { channel: "email", contact: from, name: String(b.name || "").slice(0, 80) }, text);
    if (subject && conv.subject !== subject) { conv.subject = subject; await saveConv(conv); }
    return res.json({ reply });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: friendlyError(e) });
  }
}
