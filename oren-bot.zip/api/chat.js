// Website widget endpoint.
// GET  /api/chat?config=1          -> public bot look (name, welcome, color)
// GET  /api/chat?session=<id>      -> messages of that visitor's conversation
// POST /api/chat {session, text}   -> store message, return bot reply
import { cors, readBody, handleIncoming, getConv, getSettings, friendlyError } from "./_lib.js";

const validSession = (s) => typeof s === "string" && /^[a-zA-Z0-9_-]{8,64}$/.test(s);

export default async function handler(req, res) {
  cors(res);
  if (req.method === "OPTIONS") return res.status(204).end();
  try {
    if (req.method === "GET") {
      if (req.query.config) {
        const s = await getSettings().catch(() => null);
        return res.json({ botName: s?.botName || "בוט", welcome: s?.welcome || "היי!", color: s?.color || "#7c6cff" });
      }
      if (!validSession(req.query.session)) return res.status(400).json({ error: "session חסר" });
      const c = await getConv("web:" + req.query.session);
      const messages = (c?.messages || []).map((m) => ({ role: m.role === "user" ? "user" : "bot", text: m.text, at: m.at }));
      return res.json({ messages });
    }
    if (req.method !== "POST") return res.status(405).end();
    const { session, text, name } = await readBody(req);
    if (!validSession(session)) return res.status(400).json({ error: "session חסר" });
    const msg = String(text || "").trim().slice(0, 2000);
    if (!msg) return res.status(400).json({ error: "הודעה ריקה" });
    const page = String(req.headers.referer || "").slice(0, 200);
    const { reply } = await handleIncoming(
      "web:" + session,
      { channel: "web", contact: page || "אתר", name: String(name || "").slice(0, 60) },
      msg
    );
    return res.json({ reply });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: friendlyError(e) });
  }
}
