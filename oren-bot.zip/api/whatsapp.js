// Meta WhatsApp Cloud API webhook.
// GET  -> Meta's verification handshake (hub.challenge)
// POST -> incoming messages: answer with the bot and send the reply back on WhatsApp
import { readBody, handleIncoming, sendWhatsApp, firstTime } from "./_lib.js";

export default async function handler(req, res) {
  if (req.method === "GET") {
    const q = req.query;
    const verify = (process.env.WA_VERIFY_TOKEN || "").trim();
    if (q["hub.mode"] === "subscribe" && verify && q["hub.verify_token"] === verify) {
      return res.status(200).send(q["hub.challenge"]);
    }
    return res.status(403).send("verify token mismatch");
  }
  if (req.method !== "POST") return res.status(405).end();

  const body = await readBody(req);
  try {
    for (const entry of body.entry || []) {
      for (const change of entry.changes || []) {
        const v = change.value || {};
        const myId = (process.env.WA_PHONE_ID || "").trim();
        if (myId && v.metadata?.phone_number_id && v.metadata.phone_number_id !== myId) continue;
        const names = Object.fromEntries((v.contacts || []).map((c) => [c.wa_id, c.profile?.name || ""]));
        for (const m of v.messages || []) {
          if (m.id && !(await firstTime("wa:" + m.id))) continue;
          const from = m.from;
          let text = "";
          if (m.type === "text") text = m.text?.body || "";
          else if (m.type === "button") text = m.button?.text || "";
          else if (m.type === "interactive") text = m.interactive?.button_reply?.title || m.interactive?.list_reply?.title || "";
          else text = `[נשלח ${m.type}, הבוט קורא רק טקסט]`;
          if (!text) continue;
          const { reply } = await handleIncoming("wa:" + from, { channel: "wa", contact: from, name: names[from] }, text);
          if (reply) await sendWhatsApp(from, reply);
        }
      }
    }
  } catch (e) {
    console.error("whatsapp webhook", e);
  }
  // Always 200, otherwise Meta keeps retrying the same message.
  return res.status(200).json({ ok: true });
}
